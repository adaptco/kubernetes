This outfit is good for today's Chicago weather: It'll be partly cloudy with a high of 39 and a low of 23. 
